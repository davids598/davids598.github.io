#imported libraries
import matplotlib.pyplot as plt, os, os.path, numpy as np
#finds directory of this file
directory = os.path.dirname(os.path.realpath(__file__))
# Get the income and crime rate data from CSV that has data of household income, population, and crime rates 
crimeRatesByCityFile = open(os.path.join(directory,'final.csv'),'r')
crimeRatesByCityData = crimeRatesByCityFile.readlines()
#lists that hold information about household and percentage of crimes to plot later in code
household = []
percentageOfCrimes = []
#goes through file line by line, skipping first line (first line is header)
for Line in crimeRatesByCityData[1:]:
    city,income,Population,Crime, placeholder = Line.split(',')
    household.append(income)
    percentageOfCrime = float(Crime)/float(Population)
    percentageOfCrimes.append(percentageOfCrime)

#plots graphs, one that has a smaller ylim and one with a larger ylim
fig, ax = plt.subplots(1, 2)
#calculates correlation coefficient to determine if there is a correlation between household income and percentage of crime rates
correlation = np.corrcoef(np.array(household).astype(np.float), np.array(percentageOfCrimes).astype(np.float))
#prints correlation coefficient
print 'The correlation coefficient is',correlation[1][0]
#creates scatter plots
ax[0].scatter(household, percentageOfCrimes)
ax[1].scatter(household, percentageOfCrimes)
#sets title and labels for x and y axis
ax[0].set_title('Household Income vs Crime Rate')
ax[1].set_title('Household Income vs Crime Rate')
ax[0].set_xlabel('Household Income')
ax[1].set_xlabel('Household Income')
ax[0].set_ylabel('Percentage of Crime')
ax[1].set_ylabel('Percentage of Crime')
#sets limits for graphs
ax[0].set_xlim(0, 250000)
ax[1].set_xlim(0, 250000)
ax[0].set_ylim(0, .4)
ax[1].set_ylim(0, .8)
#shows image
plt.show()